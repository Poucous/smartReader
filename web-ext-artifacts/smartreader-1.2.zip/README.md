# Smart Reader - Bionic Reading
Smart Reader or Bionic reading is a way to keep our focus on the web.
The fact that the beginnings of words are bolded, keeps your eyes on alert.

# Installation
The extension is already on Mozilla ! Just need to install and enjoy.
# https://addons.mozilla.org/firefox/addon/smartreader/
